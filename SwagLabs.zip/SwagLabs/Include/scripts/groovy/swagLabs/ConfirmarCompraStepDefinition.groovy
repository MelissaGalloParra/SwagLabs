package swagLabs
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable
import question.ValidoTotalProducto
import task.IngresoDatos

import org.openqa.selenium.WebElement
import org.openqa.selenium.WebDriver
import org.openqa.selenium.By

import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory
import com.kms.katalon.core.webui.driver.DriverFactory

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObjectProperty

import com.kms.katalon.core.mobile.helper.MobileElementCommonHelper
import com.kms.katalon.core.util.KeywordUtil

import com.kms.katalon.core.webui.exception.WebElementNotFoundException

import cucumber.api.java.en.And
import cucumber.api.java.en.Given
import cucumber.api.java.en.Then
import cucumber.api.java.en.When
import interaciones.IngresoCarrito



class ConfirmarCompraStepDefinition {
	@When("Yo abro el carrito")
	public void yo_abro_el_carrito() {
		IngresoCarrito.carrito()
	}
	
	@When("Yo ingreso los datos para verificar mi información")
	public void yo_ingreso_los_datos_para_verificar_mi_información() {
		IngresoDatos.validaciónInformacion()
	}
	
	@Then("Yo valido el total de los productos")
	public void yo_valido_el_total_de_los_productos() {
		ValidoTotalProducto.totalValor()
	}
	
	@When("Yo Finalizo la confirmación del producto")
	public void yo_Finalizo_la_confirmación_del_producto() {
		IngresoCarrito.finalizoCompra()
	}
	
	@Then("Yo verifico el logo de Pony y vuelvo al BackHome")
	public void yo_verifico_el_logo_de_Pony_y_vuelvo_al_BackHome() {
		ValidoTotalProducto.validaciónPonyYHome()
	}
}
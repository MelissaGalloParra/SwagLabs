$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/mgallo/git/SwagLabs/Include/features/LoginUsuario.feature");
formatter.feature({
  "name": "Ingreso del Usuario",
  "description": "  Yo como usuario ingreso al aplicativo Swag Labs",
  "keyword": "Feature",
  "tags": [
    {
      "name": "@tag"
    }
  ]
});
formatter.scenario({
  "name": "Ingreso del Usuario al aplicativo",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    }
  ]
});
formatter.step({
  "name": "Yo como usuario ingreso a Swag Labs",
  "keyword": "Given "
});
formatter.match({
  "location": "LoginUsuarioStepDefinitions.yo_como_usuario_ingreso_a_Swag_Labs()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Yo ingreso Usuario",
  "keyword": "When "
});
formatter.match({
  "location": "LoginUsuarioStepDefinitions.yo_ingreso_Usuario()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Yo ingreso Contraseña",
  "keyword": "When "
});
formatter.match({
  "location": "LoginUsuarioStepDefinitions.yo_ingreso_Contraseña()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Yo verifico que ingrese al aplicativo",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginUsuarioStepDefinitions.yo_verifico_que_ingrese_al_aplicativo()"
});
formatter.result({
  "status": "passed"
});
});
$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/mgallo/git/SwagLabs/Include/features/AddProducto.feature");
formatter.feature({
  "name": "Ingreso del Usuario",
  "description": "  Yo como usuario ingreso al aplicativo Swag Labs",
  "keyword": "Feature",
  "tags": [
    {
      "name": "@tag"
    }
  ]
});
formatter.scenario({
  "name": "Ingreso del Usuario al aplicativo",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    }
  ]
});
formatter.step({
  "name": "Yo como usuario ingreso a Swag Labs",
  "keyword": "Given "
});
formatter.match({
  "location": "LoginUsuarioStepDefinitions.yo_como_usuario_ingreso_a_Swag_Labs()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Yo ingreso Usuario",
  "keyword": "When "
});
formatter.match({
  "location": "LoginUsuarioStepDefinitions.yo_ingreso_Usuario()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Yo selecciono el producto",
  "keyword": "When "
});
formatter.match({
  "location": "AddProductoStepDefinition.yo_selecciono_el_producto()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Yo miro los detalles del procuto",
  "keyword": "When "
});
formatter.match({
  "location": "AddProductoStepDefinition.yo_miro_los_detalles_del_procuto()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Yo agrego el producto al carrito",
  "keyword": "Then "
});
formatter.match({
  "location": "AddProductoStepDefinition.yo_agrego_el_producto_al_carrito()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Yo cierro la ventana",
  "keyword": "Then "
});
formatter.match({
  "location": "AddProductoStepDefinition.yo_cierro_la_ventana()"
});
formatter.result({
  "status": "passed"
});
});
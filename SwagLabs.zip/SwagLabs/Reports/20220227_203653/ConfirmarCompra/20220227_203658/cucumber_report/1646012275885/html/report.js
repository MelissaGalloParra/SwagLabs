$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/mgallo/git/SwagLabs/Include/features/ConfirmarCompra.feature");
formatter.feature({
  "name": "Ingreso del Usuario",
  "description": "  Yo como usuario ingreso al aplicativo Swag Labs",
  "keyword": "Feature",
  "tags": [
    {
      "name": "@tag"
    }
  ]
});
formatter.scenario({
  "name": "Ingreso del Usuario al aplicativo",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@tag"
    }
  ]
});
formatter.step({
  "name": "Yo como usuario ingreso a Swag Labs",
  "keyword": "Given "
});
formatter.match({
  "location": "LoginUsuarioStepDefinitions.yo_como_usuario_ingreso_a_Swag_Labs()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Yo ingreso Usuario",
  "keyword": "When "
});
formatter.match({
  "location": "LoginUsuarioStepDefinitions.yo_ingreso_Usuario()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Yo selecciono el producto",
  "keyword": "When "
});
formatter.match({
  "location": "AddProductoStepDefinition.yo_selecciono_el_producto()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Yo miro los detalles del procuto",
  "keyword": "When "
});
formatter.match({
  "location": "AddProductoStepDefinition.yo_miro_los_detalles_del_procuto()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Yo agrego el producto al carrito",
  "keyword": "Then "
});
formatter.match({
  "location": "AddProductoStepDefinition.yo_agrego_el_producto_al_carrito()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Yo abro el carrito",
  "keyword": "When "
});
formatter.match({
  "location": "ConfirmarCompraStepDefinition.yo_abro_el_carrito()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Yo ingreso los datos para verificar mi información",
  "keyword": "When "
});
formatter.match({
  "location": "ConfirmarCompraStepDefinition.yo_ingreso_los_datos_para_verificar_mi_información()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Yo valido el total de los productos",
  "keyword": "Then "
});
formatter.match({
  "location": "ConfirmarCompraStepDefinition.yo_valido_el_total_de_los_productos()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Yo Finalizo la confirmación del producto",
  "keyword": "When "
});
formatter.match({
  "location": "ConfirmarCompraStepDefinition.yo_Finalizo_la_confirmación_del_producto()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Yo verifico el logo de Pony y vuelvo al BackHome",
  "keyword": "Then "
});
formatter.match({
  "location": "ConfirmarCompraStepDefinition.yo_verifico_el_logo_de_Pony_y_vuelvo_al_BackHome()"
});
formatter.result({
  "status": "passed"
});
});